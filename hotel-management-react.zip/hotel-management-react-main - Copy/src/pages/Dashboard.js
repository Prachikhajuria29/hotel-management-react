import React from "react";
import BillForm from "../components/bill/BillForm";
import hotels from "../img/hotels.png"
import Navbar from "../components/util/Navbar";


const getUserRole = () => {
    const token = localStorage.getItem("token");
    if (!token) return null;
    try {
        const payload = JSON.parse(atob(token.split(".")[1]));
        return payload.role;
    } catch (e) {
        return null;
    }
};

const Dashboard = () => {
    const role = getUserRole();
	 
    return (
        <div
            style={{
                backgroundImage: `url(${hotels})`,
                backgroundRepeat: 'no-repeat',
                backgroundPosition: 'center center',
                backgroundAttachment: 'fixed',
                backgroundSize: 'cover',
                height: '100vh',
                overflow: 'auto',
            }}
        >
            <Navbar/>
            <BillForm />
        </div>
    );
};

export default Dashboard;
