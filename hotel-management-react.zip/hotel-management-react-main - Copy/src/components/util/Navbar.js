import { Link, useNavigate } from "react-router-dom";

const Navbar = () => {
	const navigate = useNavigate();

	const handleLogout = () => {
		localStorage.removeItem("token");
		window.location.href = "/";
	};

	const getUserRole = () => {
		const token = localStorage.getItem("token");
		if (!token) return null;
		try {
			const payload = JSON.parse(atob(token.split(".")[1]));
			return payload.role;
		} catch (e) {
			return null;
		}
	};

	const role = getUserRole();

	return (
		// <!-- Navbar -->
		<nav className="navbar navbar-expand-lg" style={{ 
            background: "linear-gradient(90deg, #bcaaa4 0%, #a1887f 100%)", // slightly darker coffee gradient
            color: "#3e2723" // deeper coffee text
        }}>
			{/* <!-- Container wrapper --> */}
			<div className="container-fluid">
				{/* <!-- Toggle button --> */}
				<button
					className="navbar-toggler"
					type="button"
					data-bs-toggle="collapse"
					data-bs-target="#navbarSupportedContent"
					aria-controls="navbarSupportedContent"
					aria-expanded="false"
					aria-label="Toggle navigation"
					style={{ borderColor: "#3e2723" }}
				>
					<i className="fas fa-bars" style={{ color: "#3e2723" }}></i>
				</button>

				{/* <!-- Collapsible wrapper --> */}
				<div className="collapse navbar-collapse" id="navbarSupportedContent">
					{/* <!-- Left links --> */}
					<ul className="navbar-nav me-auto mb-2 mb-lg-0">
						<li className="nav-item">
							<Link to="/dashboard" className="nav-link" style={{ color: "#3e2723" }}>
								Billing
							</Link>
						</li>
						<li className="nav-item">
							<Link className="nav-link" to="/reservation" style={{ color: "#3e2723" }}>
								Reservation
							</Link>
						</li>
						<li className="nav-item">
							<Link className="nav-link" to="/room-service" style={{ color: "#3e2723" }}>
								Room-Service
							</Link>
						</li>
						{/* Inventory: show for admin and manager only */}
						{(role === "ROLE_ADMIN" || role === "ROLE_MANAGER") && (
							<li className="nav-item dropdown">
								<a
									className="nav-link dropdown-toggle"
									href="#"
									id="navbarDropdownInventory"
									role="button"
									data-bs-toggle="dropdown"
									aria-expanded="false"
									style={{ color: "#3e2723" }}
								>
									Inventory
								</a>
								<ul className="dropdown-menu" aria-labelledby="navbarDropdownInventory">
									<li>
										<Link className="dropdown-item" to="/inventory/item">
											Item
										</Link>
									</li>
									<li>
										<Link className="dropdown-item" to="/inventory/room">
											Room
										</Link>
									</li>
									<li>
										<Link className="dropdown-item" to="/inventory/staff">
											Staff
										</Link>
									</li>
								</ul>
							</li>
						)}
						{/* Department: show for admin only */}
						{role === "ROLE_ADMIN" && (
							<li className="nav-item">
								<Link className="nav-link" to="/department" style={{ color: "#3e2723" }}>
									Department
								</Link>
							</li>
						)}
						{/* <li className="nav-item">
							<Link className="nav-link" to="/report">
								Report
							</Link>
						</li> */}
					</ul>
					{/* <!-- Left links --> */}
				</div>
				{/* <!-- Collapsible wrapper --> */}

				{/* <!-- Right elements --> */}
				<div className="d-flex align-items-center">
					{/* <!-- Avatar --> */}
					<div className="dropdown">
						<a
							className="dropdown-toggle d-flex align-items-center hidden-arrow"
							href="#"
							id="navbarDropdownMenuAvatar"
							role="button"
							data-bs-toggle="dropdown"
							aria-expanded="false"
						>
							<img
								src="https://mdbcdn.b-cdn.net/img/new/avatars/2.webp"
								className="rounded-circle"
								height="25"
								alt="Black and White Portrait of a Man"
								loading="lazy"
							/>
						</a>
						<ul
							className="dropdown-menu dropdown-menu-end"
							aria-labelledby="navbarDropdownMenuAvatar"
						>
							<li>
								<span className="dropdown-item">
									{role === "ROLE_ADMIN" && "Admin"}
									{role === "ROLE_MANAGER" && "Manager"}
									{role === "ROLE_RECEPTION" && "Receptionist"}
								</span>
							</li>
							
							<li>
								<a className="dropdown-item" href="#" onClick={handleLogout}>
									Logout
								</a>
							</li>
						</ul>
					</div>
				</div>
				{/* <!-- Right elements --> */}
			</div>
			{/* <!-- Container wrapper --> */}
		</nav>

		// <!-- Navbar -->
	);
};

export default Navbar;
