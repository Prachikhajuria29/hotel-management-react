 package com.service.adminstration.controllers;

import java.util.List;

import org.apache.hc.core5.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.service.adminstration.entities.Department;
import com.service.adminstration.entities.Response;
import com.service.adminstration.exception.DepartmentNotFoundException;
import com.service.adminstration.services.DepartmentService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/department")
@Tag(name = "Department Controller", description = "APIs for managing departments")
public class DepartmentController {

    private static final Logger logger = LoggerFactory.getLogger(DepartmentController.class);
    private static final String RESERVATION_BASE_URL = "http://localhost:8000/reservation";

    @Autowired
    private DepartmentService departmentService;

    @Operation(summary = "Retrieve all departments")
    @GetMapping("/get")
    public List<Department> getDepartments() {
        logger.info("Fetching all departments");
        return departmentService.getDepartments();
    }

    @Operation(summary = "Retrieve a department by ID")
    @GetMapping("/getDepartmentById/{departmentId}")
    public Department getDepartmentById(@PathVariable int departmentId) {
        logger.info("Fetching department with ID {}", departmentId);
        return departmentService.getDepartmentById(departmentId);
    }

    @Operation(summary = "Save a new department")
    @PostMapping("/save")
    public Response saveDepartment(@RequestBody Department department) {
        logger.info("Received request to save department: {}", department);
        Department result = departmentService.saveDepartment(department);
        if (result != null) {
            logger.info("Department saved successfully: {}", result);
            return Response.builder()
                    .success(true)
                    .department(result)
                    .message("Department saved successfully")
                    .code(HttpStatus.SC_OK)
                    .build();
        } else {
            logger.error("Failed to save department: {}", department);
            return Response.builder()
                    .success(false)
                    .message("Department not saved successfully")
                    .department(department)
                    .code(HttpStatus.SC_BAD_REQUEST)
                    .build();
        }
    }

    @Operation(summary = "Update a department")
    @PutMapping("/update/{id}")
    public Response updateDepartment(@RequestBody Department department, @PathVariable int id) {
        logger.info("Received request to update department with ID {}: {}", id, department);
        try {
            Department result = departmentService.updateDepartment(department, id);
            logger.info("Department updated successfully: {}", result);
            return Response.builder()
                    .success(true)
                    .department(result)
                    .message("Department updated successfully")
                    .code(HttpStatus.SC_OK)
                    .build();
        } catch (DepartmentNotFoundException e) {
            logger.error("Failed to update department with ID {}: {}", id, e.getMessage());
            return Response.builder()
                    .success(false)
                    .department(department)
                    .message(e.getMessage())
                    .code(HttpStatus.SC_BAD_REQUEST)
                    .build();
        }
    }

    @Operation(summary = "Delete a department by ID")
    @DeleteMapping("/delete/{id}")
    public Response deleteDepartment(@PathVariable int id) {
        logger.info("Received request to delete department with ID {}", id);
        try {
            departmentService.deleteDepartment(id);
            logger.info("Department deleted successfully with ID {}", id);
            return Response.builder()
                    .success(true)
                    .department(null)
                    .message("Department deleted successfully")
                    .code(HttpStatus.SC_OK)
                    .build();
        } catch (DepartmentNotFoundException e) {
            logger.error("Failed to delete department with ID {}: {}", id, e.getMessage());
            return Response.builder()
                    .success(false)
                    .department(null)
                    .message(e.getMessage())
                    .code(HttpStatus.SC_BAD_REQUEST)
                    .build();
        }
    }
}
