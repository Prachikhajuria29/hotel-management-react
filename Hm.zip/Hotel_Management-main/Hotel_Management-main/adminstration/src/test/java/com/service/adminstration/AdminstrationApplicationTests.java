package com.service.adminstration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminstrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
