package com.service.authentication.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_MANAGER', 'ROLE_RECEPTION')")
@Tag(name = "Payment Controller", description = "APIs for payment operations")
public class PaymentController {

    private static final Logger logger = LoggerFactory.getLogger(PaymentController.class);

    @Autowired
    private RestTemplate restTemplate;

    private static final String PAYMENT_BASE_URL = "http://localhost:8006";

    @Operation(summary = "Initiate a payment", description = "Initiates a payment for a specified amount and returns the response.")
    @GetMapping("/payment/{amount}")
    public String Payment(@PathVariable int amount) throws Exception {
        logger.info("Received request to initiate payment for amount: {}", amount);
        try {
            String order = restTemplate.getForObject(PAYMENT_BASE_URL + "/payment/{amount}", String.class, amount);
            logger.info("Payment processed successfully, response: {}", order);
            return order;
        } catch (Exception e) {
            logger.error("Error occurred while processing payment for amount: {}", amount, e);
            throw new Exception("Payment processing failed", e);
        }
    }
}
