package com.service.authentication.exception;

@SuppressWarnings("serial")
public class UserErrorException extends Exception {
    public UserErrorException(String msg) {
        super(msg);
    }
}
