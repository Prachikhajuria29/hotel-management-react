package com.service.room.exception;

public class RoomServiceNotFound extends Exception {
    public RoomServiceNotFound(String message) {
        super(message);
    }

}
