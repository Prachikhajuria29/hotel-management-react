package com.service.inventory.exception;

public class RoomAlreadyExists extends Exception {
    public RoomAlreadyExists(String message) {
        super(message);
    }
}
